import com.mongodb.*;
import java.util.*;
import java.net.UnknownHostException;

public class MongoWriteCluster   {
	public static void main(String[] args) {
		int i;
		MongoClient mongoClient = null;
		MongoClient mongoClient1 = new MongoClient( 		  
		new MongoClientURI("mongodb://localhost:27017,localhost:25017,localhost:23017/?replicaSet=replicademo"));
		DB db = mongoClient1.getDB("db_demo");
		i=1;
		DBCollection table = db.getCollection("collection_demo");
		while(i<6) {
			
			BasicDBObject document = new BasicDBObject();
			document.put("Nome",i);
			try { table.insert(document);} catch (Exception e) {}
			i++;
			try{Thread.sleep(5000);} catch (InterruptedException  e) {Thread.currentThread().interrupt();}
		}
		mongoClient1.close();		
	}
}	
