
import com.mongodb.*;
import java.util.*;

public class MongoReadCluster   {
	public static void main(String[] args) {
		MongoClient mongoClient1 = new MongoClient( new MongoClientURI("mongodb://localhost:27017,localhost:25017,localhost:23017/?replicaSet=replicademo"));

		DB db = mongoClient1.getDB("db_demo");
		DBCollection table = db.getCollection("collection_demo");
		DBCursor cursor = table.find();
		while(cursor.hasNext()) {
		    System.out.println(cursor.next());
		  }

    }
}
